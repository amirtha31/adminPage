export default function EditUser(){
    return (
        <h1> Edit users</h1>
    )
}
