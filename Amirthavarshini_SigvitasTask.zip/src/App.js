import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import './App.css';
import List from './Components/List';
import CreateUser from './Components/CreateUser';
import EditUser from './Components/EditUser';
import Login from './Components/Login';
import Exceldata from './Components/Exceldata';
import Front from './Components/Front';
import { MantineProvider } from '@mantine/core';

function App() {
  return (
    <div className="App">
      <MantineProvider defaultColorScheme="dark">

      
      {/* <h5>React CRUD operations using PHP API and MySQL</h5> */}
      <BrowserRouter>
        {/* <nav>
          <ul>
          <li>
              <Link to="/">Front Page</Link>
            </li>
            <li>
              <Link to="List">List Users</Link>
            </li>
            <li>
              <Link to="user/create">Create user</Link>
            </li>
            <li>
              <Link to="user/login">User login</Link>
            </li>
            <li>
              <Link to="add/data">Add excel data</Link>
            </li> 
              
          </ul>
        </nav> */}
        <Routes>
          <Route index element={<Front></Front>}></Route>
          <Route path="List" element={<List/>}></Route>
          <Route path="user/create" element={<CreateUser/>}></Route>
          <Route path="user/login" element={<Login/>}></Route>
          <Route path="user/:id/edit" element={<EditUser/>}></Route>
          <Route path="add/data" element={<Exceldata/>}></Route>
         
        </Routes>
      </BrowserRouter>
      </MantineProvider>
    </div>


  );
}

export default App;
